import java.sql.*;

public class proc {
public static void main(String[] args) throws Exception{ 
	try{
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
		Connection con=DriverManager.getConnection("jdbc:sqlserver://172.16.25.16:1433;databaseName=adfuatcab","sa","p@ssw0rd");
		CallableStatement stmt=con.prepareCall("{call NG_PROC_COLLECTIONS_DELINQUENCY}");
		stmt.execute();
		System.out.println("Executing procedure success"); 
	}
	catch (SQLException sqle)
	{
		sqle.printStackTrace();
		System.out.println(" Exception :: "+sqle.getMessage());
	}
	catch (Exception e)
	{
		e.printStackTrace();
		System.out.println(" Exception :: "+e.getMessage());
	}
}  
}  